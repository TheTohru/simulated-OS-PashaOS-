//PashaOS SystemSecurity.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PashaOS
{
    public class SystemSecurity
    {
        user u = new user();
        public void UserSecurity()
        {
            
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Select what data you want to change: ");
            Console.ResetColor();
            Console.WriteLine("Change username - 1");
            Console.WriteLine("Change password - 2");
            Console.WriteLine("Change role - 3");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("=>");
            Console.ResetColor();
            try
            {
                string choice = Console.ReadLine();
            
                bool error = true;
                while(error)
                {
                    switch(choice)
                    {
                        case "1":
                            Console.Clear();
                            u.NewUsername();
                            break;

                        case "2":
                            Console.Clear();
                            u.NewPassword();
                            break;

                        case "3":
                            Console.Clear();
                            u.NewRole();
                            break;

                        default:
                            Console.WriteLine("Error, please try again");
                            error = true;
                            break;
                    }
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Please try again, error message: " +  ex.Message);
            }

           
        }

        public bool CheckSecurity()
        {
            Console.WriteLine("Checking system security status...");
            return true;
        }
        public void ShowSecurityKnowledge()
        {
            Console.WriteLine("Security information: ");
            Console.WriteLine(@"
            ");

            Console.WriteLine("Security system in use: PashaOS Security System");
            Console.WriteLine("Security system version: 2.5.7 latest version");
            Console.WriteLine("User security provider: running since the OS started...");
            Console.WriteLine("Internet security: 'The OS does not require internet!'");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("------------------------------------------------------------------------");
            Console.ForegroundColor= ConsoleColor.Blue;
            Console.WriteLine("Looking for other options?");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Menu 0 - Settings 1 - Change user info 2");
            Console.WriteLine(@"
            ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("=>");
            Console.ResetColor();
            bool error = true;
            try
            {
                while (error)
                {
                    string choice = Console.ReadLine();

                    switch (choice)
                    {
                        case "0":
                            Console.Clear();
                            menu menu = new menu();
                            menu.ShowMenu();
                            break;

                        case "1":
                            Console.Clear();
                            settings settings = new settings();
                            settings.ShowSettings();
                            break;

                        case "2":
                            Console.Clear();
                            UserSecurity();
                            break;

                        default:
                            Console.WriteLine("Invalid input, please try again...");
                            error = true;
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Invalid input, error message: " +  ex.Message);
            }



        }
        
    }
}

