//PashaOS SystemUpdate.cs

using System;
using System.IO;
using System.Text;

namespace PashaOS
{
    public class SystemUpdate
    {
        private string CurrentVersion = "0.0.1";

        public bool UpdateOS()
        {
            Console.OutputEncoding = Encoding.UTF8;
            string latestVersion = "1.0.0";

            Version current = new Version(CurrentVersion);
            Version latest = new Version(latestVersion);

            if (current.CompareTo(latest) >= 0)
            {
                Console.WriteLine($"You are already using the latest version. Version: {CurrentVersion}");
                return false;
            }
            else
            {
                Console.WriteLine($"A new version is available: {latestVersion}. Do you want to update? (y/n)");
                string response = Console.ReadLine();
                if (response?.ToLower() == "y")
                {
                    DownloadUpdate();
                    return true;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("⚠ Update is recommended, but no action was taken.");
                    Console.WriteLine("You may remain on an older version and miss future updates. Please download the update manually as a ZIP file.");
                    Console.ResetColor();
                    return false;
                }
            }
        }

        private void DownloadUpdate()
        {
            Console.OutputEncoding = Encoding.UTF8;
            string source = "updates/NewKernel.dll";
            string destination = "system/Kernel.dll";

            if (File.Exists(source))
            {
                File.Copy(source, destination, true);
                Console.WriteLine("Update completed successfully!");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("⚠ Update is recommended, but no action was taken.");
                Console.WriteLine("You may remain on an older version and miss future updates. Please download the update manually as a ZIP file.");
                Console.ResetColor();
            }
        }
    }
}

