//PashaOS kernel.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PashaOS
{
    public class kernel
    {
        public void startkernel()
        {
            Console.WriteLine("PashaOS launched...");
            System.Threading.Thread.Sleep(5000);
            Console.WriteLine("applications are starting...");
            System.Threading.Thread.Sleep(1500);
            Console.WriteLine("Loading PashaOS Terminal...");
            System.Threading.Thread.Sleep(3000);
            Console.WriteLine("This process may take some time....");
            
            for(int i = 1; i < 5; i++)
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("The package installer has finished its process: " + i);
                System.Threading.Thread.Sleep(50);
                for(int j = 0; j < 10; j++)
                {
                    Console.Write(" █ ");
                    System.Threading.Thread.Sleep(100);
                }

            }
            Console.ResetColor();
            Console.WriteLine("Kernel structure was checked and completed successfully.");
            System.Threading.Thread.Sleep(2000);
            Console.Clear();
            Console.WriteLine("You are ready to get started, you are being directed to create an account...");
            System.Threading.Thread.Sleep(2000);
        }
    }
}

