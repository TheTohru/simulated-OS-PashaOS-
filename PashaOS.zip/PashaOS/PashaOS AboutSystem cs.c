//PashaOS AboutSystem.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PashaOS
{
    public class AboutSystem
    {
        public void ShowAboutSystem()
        {
            Console.WriteLine(@"Hello, if you came here out of curiosity, welcome. My aim in this project is to gain experience and improve myself. Although the project was very challenging for me, I created the full version. If you are a developer, you can review or change the codes I wrote.");

            
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Written by PashaOS developer");
            Console.ResetColor();

            Console.WriteLine(@"
            ");
            Console.WriteLine("Type 0 to exit");
            bool again = true;
            while (again)
            {

                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("=> ");
                Console.ResetColor();

                string secim = Console.ReadLine();
                if (secim == "0")
                {
                    again = false;
                    Console.Clear();
                    menu menu = new menu();
                    menu.showmenu();
                }
                else
                {
                    Console.WriteLine("wrong choice please try again");
                    again = true;

                }
            }

        }
    }
}
