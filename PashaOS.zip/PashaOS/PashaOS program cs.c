//PashaOS program.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PashaOS
{
    internal class Program
    {
        static void Main(string[] args)
        {
            

            boot b = new boot();
            b.startboot();
            kernel k = new kernel(); 
            k.startkernel();
            
            user user = new user();
            user.access();
        }
    }
}
