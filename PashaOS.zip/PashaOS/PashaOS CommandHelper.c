//PashaOS CommandHelper.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PashaOS
{
    public class CommandHelper
    {
        //kullanıcının kolaylıkla bakması için hazırlandı
        public static void TerminalHelp()
        {
            Console.WriteLine(@"
PashaOS Terminal

- u

/open.ShowBasicApps()//
/open.ShowCalculator()//
/open.ShowFileCreater()//
/open.ShowNotes()//
/open.ShowTimer()//

- operating system commands

/ReStartOS;
/ShutDownOS;
/DeleteOS;
/open.ShowOSMenu()
/open.ShowOSSettings()
/Show.SystemKnowledge;
/Show.AllSystemKnowledge;

- user commands

/ShowMyKnowledge;
/DeleteMyKnowledge;
/ChangeMyKnowledge;

- basic commands

/Show.DateTime;
!Help
/ChangeTerminalColor;
/ChangeBackRoundColor;
/SetColor = "" "";
/ClearTerminal;
/ClearAllColor;
/CLearFontColor;
/ClearBackRoundColor;
Show.PrintConsole = "" "";

- system update and reporting

/ReportBug;
/ShowSystemVersion;
/CheckForUpdate;

- file operation

/open.ShowFileCreater()
/ListAllFile;
/FoundMyFile;
/DeleteFile;
            ");

        }
    }
}
