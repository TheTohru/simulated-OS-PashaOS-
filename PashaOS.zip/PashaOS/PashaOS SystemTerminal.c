// PashaOS SystemTerminal.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PashaOS
{
    public class SystemTerminal
    {
        public void ShowSystemTerminal()
        {
            menu menu = new menu();
            settings settings = new settings();
            user user = new user();
            kernel kernel = new kernel();
            boot boot = new boot();
            basicapps apps = new basicapps();

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(@"

 _______                __               _________                              _                   __   
|_   __ \              [  |             |  _   _  |                            (_)                 [  |  
  | |__) |,--.   .--.   | |--.   ,--.   |_/ | | \_|.---.  _ .--.  _ .--..--.   __   _ .--.   ,--.   | |  
  |  ___/`'_\ : ( (`\]  | .-. | `'_\ :      | |   / /__\\[ `/'`\][ `.-. .-. | [  | [ `.-. | `'_\ :  | |  
 _| |_   // | |, `'.'.  | | | | // | |,    _| |_  | \__., | |     | | | | | |  | |  | | | | // | |, | |  
|_____|  \'-;__/[\__) )[___]|__]\'-;__/   |_____|  '.__.'[___]   [___||__||__][___][___||__]\'-;__/[___] 
Fast and user-friendly Command Manager...                                                                                                         

            ");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("If you don’t know the shortcuts or commands to enter, type '!Help'... (The terminal is case-sensitive, please type accurately!)");
            Console.ResetColor();

            bool again = true;
            while (again)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("=> ");
                Console.ResetColor();

                string command = Console.ReadLine();
                if (command == "!Help")
                {
                    CommandHelper.TerminalHelp();
                }
                else if (command == "/ClearTerminal;")
                {
                    Console.Clear();
                    ShowSystemTerminal();
                }
                else if (command == "/Show.DateTime;")
                {
                    Console.WriteLine("Date: " + DateTime.Now);
                }
                else if (command == "/ReStartOS;")
                {
                    Console.Clear();
                    kernel.startkernel();
                    boot.startboot();
                    menu.showmenu();
                }
                else if (command == "/ShutDownOS;")
                {
                    Console.Clear();
                    Console.WriteLine("System shut down...");
                }
                else if (command == "/DeleteOS;")
                {
                    Console.Clear();
                    Console.WriteLine("The OS will be shut down and deleted. Are you sure? (y/n)");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("=> ");
                    Console.ResetColor();
                    string choice = Console.ReadLine();
                    bool confirm = true;
                    while (confirm)
                    {
                        if (choice == "y")
                        {
                            Console.Clear();
                            Console.WriteLine("The operating system was destroyed, for now.");
                            confirm = false;
                            Environment.Exit(0);
                        }
                        else if (choice == "n")
                        {
                            Console.Clear();
                            Console.WriteLine("Continuing operation, redirecting to main menu for safety...");
                            confirm = false;
                            System.Threading.Thread.Sleep(3000);
                            Console.Clear();
                            menu.showmenu();
                        }
                        else
                        {
                            Console.WriteLine("Invalid choice, please try again.");
                            confirm = false;
                        }
                    }
                }
                else if (command == "/open.ShowOSMenu")
                {
                    Console.Clear();
                    Console.WriteLine("Please wait...");
                    System.Threading.Thread.Sleep(1500);
                    Console.Clear();
                    menu.showmenu();
                }
                else if (command == "/open.ShowOSSettings()")
                {
                    Console.Clear();
                    settings.ShowSettings();
                }
                else if (command == "/Show.SystemKnowledge;")
                {
                    Console.Clear();
                    settings.showsystemknowledge();
                }
                else if (command == "/ShowMyKnowledge;")
                {
                    Console.Clear();
                    user.showuser();
                }
                else if (command == "/DeleteMyKnowledge;")
                {
                    Console.Clear();
                    Console.WriteLine("User data deleted. You may continue without it...");
                    Console.WriteLine("Redirecting to main menu...");
                    System.Threading.Thread.Sleep(1500);
                    menu.showmenu();
                }
                else if (command == "/ChangeMyKnowledge;")
                {
                    bool changeAgain = true;
                    Console.WriteLine("Select the information you want to change (1 - Change username) (2 - Change password)");
                    while (changeAgain)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.Write("=> ");
                        Console.ResetColor();

                        string choice1 = Console.ReadLine();

                        if (choice1 == "1")
                        {
                            Console.Clear();
                            user.newusername();
                        }
                        else if (choice1 == "2")
                        {
                            Console.Clear();
                            user.newpassword();
                        }
                        else
                        {
                            Console.WriteLine("Error, try again.");
                            changeAgain = true;
                        }
                    }
                }
                else if (command == "/ReportBug;")
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("If you found a bug, check the link below to reach my GitHub profile. If you're a developer, try to fix it yourself!");
                    Console.ResetColor();
                    Console.WriteLine("https://github.com/TheTohru\r\n");
                }
                else if (command == "/ShowSystemVersion;")
                {
                    Console.WriteLine("0.0.1 Pasha Operating System (latest)");
                }
                else if (command == "/CheckForUpdate;")
                {
                    SystemUpdate systemUpdate = new SystemUpdate();
                    systemUpdate.UpdateOS();
                }
                else if (command == "/open.ShowBasicApps()")
                {
                    Console.Clear();
                    apps.ShowBasicApps();
                }
                else if (command == "/open.ShowCalculator()")
                {
                    Console.Clear();
                    apps.ShowCalculator();
                }
                else if (command == "/open.ShowFileCreater()")
                {
                    Console.Clear();
                    apps.Fileoperation();
                }
                else if (command == "/open.ShowNotes()")
                {
                    Console.Clear();
                    apps.Note();
                }
                else if (command == "/open.ShowTimer()")
                {
                    Console.Clear();
                    apps.timer();
                }
            }
        }
    }
}

