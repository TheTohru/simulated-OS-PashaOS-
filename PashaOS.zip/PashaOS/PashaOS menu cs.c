//PashaOS menu.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PashaOS
{
    public class menu
    {
        public void showmenu()
        {
            
            Console.OutputEncoding = Encoding.UTF8;
            user u = new user();
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Hello! welcome to Pasha Operating System...");

            Console.WriteLine(@" 
            
                                                               
,------.                ,--.                  ,-----.  ,---.   
|  .--. ' ,--,--. ,---. |  ,---.  ,--,--.    '  .-.  ''   .-'  
|  '--' |' ,-.  |(  .-' |  .-.  |' ,-.  |    |  | |  |`.  `-.  
|  | --' \ '-'  |.-'  `)|  | |  |\ '-'  |    '  '-'  '.-'    | 
`--'      `--`--'`----' `--' `--' `--`--'     `-----' `-----'  
fast, secure, open source and closest to reality operating system                                                              
                                                                                        

               ");

            Console.WriteLine(@"
            ");

            Console.Write("[1]");
            Console.ResetColor();
            Console.WriteLine(" ⚙️ Settings");

            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("[2]");
            Console.ResetColor();
            Console.WriteLine(" 💻 Basic apps");

            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("[3]");
            Console.ResetColor();
            Console.WriteLine(" 🎁 Basic games");

            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("[4]");
            Console.ResetColor();
            Console.WriteLine(" 🛠️ Pasha Terminal");

            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("[5]");
            Console.ResetColor();
            Console.WriteLine(" 📜 About operating system");


            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("=> ");
            Console.ResetColor();
            try
            {
                bool error = true;
                while (error)
                {

                    string choice = Console.ReadLine();

                    switch (choice)
                    {
                        case "1":
                            Console.Clear();
                            settings settings = new settings();
                            settings.ShowSettings();
                            break;
                        case "2":
                            Console.Clear();
                            basicapps apps = new basicapps();
                            apps.ShowBasicApps();
                            break;
                        case "3":
                            Console.Clear();
                            BasicGames basicGames = new BasicGames();
                            basicGames.BasicGamesMenu();
                            break;
                        case "4":
                            Console.Clear();
                            SystemTerminal terminal = new SystemTerminal();
                            terminal.ShowSystemTerminal();
                            break;
                        case "5":
                            Console.Clear();
                            AboutSystem about = new AboutSystem();
                            about.ShowAboutSystem();
                            break;
                        default:
                            Console.WriteLine("Incorrect entry please try again");
                            error = true;
                            break;
                    }
                }
            }
            catch(Exception errorOne)
            {
                Console.WriteLine("error, please try again. error message: " +  errorOne.Message);
            }


        }
    }
}
