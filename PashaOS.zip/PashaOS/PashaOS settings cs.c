//PashaOS settings.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PashaOS
{
    public class settings
    {
    
        public void ShowSettings()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("You entered the settings, are the things you are looking for here?");

            Console.WriteLine(@" 
                                                          
 ,---.           ,--.    ,--.  ,--.                       
'   .-'  ,---. ,-'  '-.,-'  '-.`--',--,--,  ,---.  ,---.  
`.  `-. | .-. :'-.  .-''-.  .-',--.|      \| .-. |(  .-'  
.-'    |\   --.  |  |    |  |  |  ||  ||  |' '-' '.-'  `) 
`-----'  `----'  `--'    `--'  `--'`--''--'.`-  / `----'  
                                           `---'  
            ");

            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("[1]");
            Console.ResetColor();
            Console.WriteLine(" ✔ go back to main menu"); //

            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("[2]");
            Console.ResetColor();
            Console.WriteLine(" 💡 operating system information"); //

            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("[3]");
            Console.ResetColor();
            Console.WriteLine(" 🔧 hardware information"); //

            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("[4]");
            Console.ResetColor();
            Console.WriteLine(" 💡 user information"); //

            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("[5]");
            Console.ResetColor();
            Console.WriteLine(" 🔒 security settings and information"); //

            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("[6]");
            Console.ResetColor();
            Console.WriteLine(" ⏳ date and time"); //
            bool error = true;
            while (error)
            {

                string secim = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        Console.Clear();
                        menu menu = new menu();
                        menu.showmenu();
                        break;
                    case "2":
                        Console.Clear();
                        showsystemknowledge();
                        break;
                    case "3":
                        Console.Clear();
                        SystemManagement systemManagement = new SystemManagement();
                        systemManagement.showknowledge();
                        break;
                    case "4":
                        Console.Clear();
                        user user = new user();
                        user.showuser();
                        break;
                    case "5":
                        Console.Clear();
                        SystemSecurity security = new SystemSecurity();
                        security.showsecurityknowledge();
                        break;
                    case "6":
                        Console.Clear();
                        dateandtime show = new dateandtime();
                        show.ShowDateAndTime();
                        break;

                        default:
                        Console.WriteLine("An error occurred, try again.");
                        error = true;
                        break;

                }
            }


        }

        public void showsystemknowledge()
        {
            Console.ForegroundColor= ConsoleColor.Red;
            Console.WriteLine("operating system information...");

            Console.WriteLine(@"
                                                               
                    ,------.                ,--.                  ,-----.  ,---.   
                    |  .--. ' ,--,--. ,---. |  ,---.  ,--,--.    '  .-.  ''   .-'  
                    |  '--' |' ,-.  |(  .-' |  .-.  |' ,-.  |    |  | |  |`.  `-.  
                    |  | --' \ '-'  |.-'  `)|  | |  |\ '-'  |    '  '-'  '.-'    | 
                    `--'      `--`--'`----' `--' `--' `--`--'     `-----' `-----' 
                                                                                ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("operating system used: ");
            Console.ResetColor();
            Console.WriteLine("PashaOS");

            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("operating system verison: ");
            Console.ResetColor();
            Console.WriteLine("0.0.1");

            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("operating system bit: ");
            Console.ResetColor();
            Console.WriteLine("16,32");

            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("the programming language used for the operating system: ");
            Console.ResetColor();
            Console.WriteLine("C#");

            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("operating system structure: ");
            Console.ResetColor();
            Console.WriteLine("Console .Net freamwork");

            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("operating system type: ");
            Console.ResetColor();
            Console.WriteLine("simulated operating system");

            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("operating system internet requirement: ");
            Console.ResetColor();
            Console.WriteLine("not necessary");

            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("operating system package installer: ");
            Console.ResetColor();
            Console.WriteLine("4");

            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("operating system software and hardware compatibility: ");
            Console.ResetColor();
            Console.WriteLine("only available on windows and linux");
            Console.WriteLine(@"
            ");
            Console.WriteLine("menu 0 - settings 1");
            Console.ForegroundColor= ConsoleColor.Red;
            Console.Write("=>");
            Console.ResetColor();
            try
            {
                bool error = true;
                while (error)
                {

                    string choice = Console.ReadLine();

                    switch (choice)
                    {
                        case "0":
                            Console.Clear();
                            menu menu = new menu();
                            menu.showmenu();
                            break;
                        case "1":
                            Console.Clear();
                            ShowSettings();
                            break;

                        default:
                            Console.WriteLine("An error occurred, try again.");
                            error = true;
                            break;
                    }
                }
            }
            catch (Exception errorOne)
            {
                Console.WriteLine("error, please try again. error message: " +  errorOne.Message);
            }




        }
    

    
    

    
    }
}
