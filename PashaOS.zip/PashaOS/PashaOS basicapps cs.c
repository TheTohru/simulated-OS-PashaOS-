// PashaOS basicapps.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Authentication;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Media;

namespace PashaOS
{
    public class basicapps
    {
        menu menu = new menu();
        public void ShowBasicApps()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(@"                  
  ,---.                        
 /  O  \  ,---.  ,---.  ,---.  
|  .-.  || .-. || .-. |(  .-'  
|  | |  || '-' '| '-' '.-'  `) 
`--' `--'|  |-' |  |-' `----'  
         `--'   `--'                                                                 

            ");

            Console.WriteLine("Welcome to the basic applications section. Please select what you want...");
            Console.ResetColor();
            Console.WriteLine("main menu 0 - calculator 1 - file creator 2 - notepad 3 - timer 4 ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("=> ");
            Console.ResetColor();
            bool error = true;
            try
            {
                while (error)
                {
                    string choice = Console.ReadLine();
                    switch (choice)
                    {
                        case "0":
                            Console.Clear();
                            menu.showmenu();
                            break;
                        case "1":
                            Console.Clear();
                            ShowCalculator();
                            break;

                        case "2":
                            Console.Clear();
                            Fileoperation();
                            break;

                        case "3":
                            Console.Clear();
                            Note();
                            break;

                        case "4":
                            Console.Clear();
                            timer();
                            break;

                        default:
                            Console.WriteLine("Invalid choice, please try again.");
                            error = false;
                            break;

                    }
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Invalid input, please try again. Error message: " +  ex.Message);
            }
        }
        public void ShowCalculator()
        {
            Calculator calculator = new Calculator();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Welcome to the calculator...");
            Console.ForegroundColor= ConsoleColor.Blue;
            Console.WriteLine("Note: Remember, this app only performs basic and simple calculations...");
            Console.ResetColor();
            Console.WriteLine(@"
            ");

            Console.ResetColor();
            Console.WriteLine("Which operation would you like to perform?");
            Console.ForegroundColor= ConsoleColor.Red;
            Console.WriteLine("addition 1 - subtraction 2 - multiplication 3 - division 4 - averaging 5 - squaring a number 6");
            Console.WriteLine(@"
            ");
            Console.Write("=> ");
            Console.ResetColor();
            bool error = true;
            try
            {
                string choice = Console.ReadLine();
                while(error)
                {
                    switch (choice)
                    {
                        case "1":
                            Console.Clear();
                            calculator.ShowAddition();
                            break;

                        case "2":
                            Console.Clear();
                            calculator.ShowSubtraction();
                            break;

                        case "3":
                            Console.Clear();
                            calculator.ShowMultiplication();
                            break;

                        case "4":
                            Console.Clear();
                            calculator.ShowDivision();
                            break;

                        case "5":
                            Console.Clear();
                            calculator.ShowAverage();
                            break;

                        case "6":
                            Console.Clear();
                            calculator.ShowSquaringaNumber();
                            break;

                        default:
                            Console.WriteLine("Error, please try again.");
                            error = true;
                            break;

                    }
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Invalid choice, please try again. Error message: " + ex.Message);
            }
        }

        public void Fileoperation()
        {
            Console.WriteLine("Please select the operation you want:");
            Console.WriteLine("Create file 1 - Delete file 2");
            string choice = Console.ReadLine();

            try
            {
                bool again = true;
                while (again)
                {
                    switch (choice)
                    {
                        case "1":
                            Console.Clear();
                            Console.WriteLine("Write the name of the file to create...");
                            string filename = Console.ReadLine();

                            if (string.IsNullOrEmpty(filename))
                            {
                                Console.WriteLine("File name cannot be empty. Please try again.");
                                continue;
                            }

                            string file = filename;

                            if (!File.Exists(file))
                            {
                                // create and close
                                using (File.Create(file))
                                {
                                    // open
                                }

                                Console.WriteLine("Would you like to write something into the file? (y/n)");
                                string choice1 = Console.ReadLine();

                                if (choice1 == "y")
                                {
                                    Console.WriteLine("Write what you want to save in the file...");
                                    Console.Write("Write: ");
                                    string filetext = Console.ReadLine();

                                    if (!string.IsNullOrEmpty(filetext))
                                    {
                                        File.WriteAllText(file, filetext);
                                        Console.WriteLine("File created and data written inside.");
                                        Console.WriteLine(@"
                                ");
                                        Console.WriteLine("Write 1 to go to the main menu...");
                                        Console.ForegroundColor = ConsoleColor.Red;
                                        Console.Write("=> ");
                                        bool retry = true;
                                        while (retry)
                                        {
                                            string sel = Console.ReadLine();
                                            if (sel == "1")
                                            {
                                                retry = false;
                                                menu.showmenu();
                                            }
                                            else
                                            {
                                                retry = true;
                                                Console.WriteLine("Invalid choice, please try again.");
                                            }
                                        }
                                    }
                                    else
                                    {
                                        Console.WriteLine("File created but no data written inside.");
                                        Console.WriteLine(@"
                                ");
                                        Console.WriteLine("Write 1 to go to the main menu...");
                                        Console.ForegroundColor = ConsoleColor.Red;
                                        Console.Write("=> ");
                                        bool retry = true;
                                        while (retry)
                                        {
                                            string sel = Console.ReadLine();
                                            if (sel == "1")
                                            {
                                                retry = false;
                                                menu.showmenu();
                                            }
                                            else
                                            {
                                                retry = true;
                                                Console.WriteLine("Invalid choice, please try again.");
                                            }
                                        }
                                    }

                                    again = false;
                                }
                                else if (choice1 == "n")
                                {
                                    Console.WriteLine("File created without writing data inside.");
                                    again = false;
                                    Console.WriteLine(@"
                                ");
                                    Console.WriteLine("Write 1 to go to the main menu...");
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.Write("=> ");
                                    bool retry = true;
                                    while (retry)
                                    {
                                        string sel = Console.ReadLine();
                                        if (sel == "1")
                                        {
                                            retry = false;
                                            menu.showmenu();
                                        }
                                        else
                                        {
                                            retry = true;
                                            Console.WriteLine("Invalid choice, please try again.");
                                        }
                                    }
                                }
                                else
                                {
                                    Console.Clear();
                                    Console.WriteLine("Invalid choice, please try again.");
                                    again = true;
                                }
                            }
                            else
                            {
                                Console.Clear();
                                Console.WriteLine("File already exists. Please enter a different file name.");
                                again = true;
                            }
                            break;

                        case "2":
                            Console.Clear();
                            Console.WriteLine("Write the name of the file you want to delete...");
                            string deleteFileName = Console.ReadLine();

                            if (File.Exists(deleteFileName))
                            {
                                File.Delete(deleteFileName);
                                Console.WriteLine("File successfully deleted.");
                                Console.WriteLine(@"
                                ");
                                Console.WriteLine("Write 1 to go to the main menu...");
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.Write("=> ");
                                bool retry = true;
                                while (retry)
                                {
                                    string sel = Console.ReadLine();
                                    if (sel == "1")
                                    {
                                        retry = false;
                                        menu.showmenu();
                                    }
                                    else
                                    {
                                        retry = true;
                                        Console.WriteLine("Invalid choice, please try again.");
                                    }
                                }
                            }
                            else
                            {
                                Console.WriteLine("The specified file was not found.");
                            }
                            again = false;
                            break;

                        default:
                            Console.WriteLine("Invalid choice, please try again.");
                            again = true;
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred, please try again. Error message: " + ex.Message);
            }
        }
        public void Note()
        {
            bool retry = true;
            try
            {
                while (retry)
                {
                    Console.WriteLine("Enter the name of the file to create for writing notes...");
                    Console.Write("file name: ");
                    string filename = Console.ReadLine();

                    if (!File.Exists(filename))
                    {
                        Console.WriteLine("File created, you can write whatever you want inside. It will be saved automatically after typing...");
                        Console.Write("Start typing here: ");
                        string note = Console.ReadLine();
                        File.WriteAllText(filename, note);
                        Console.WriteLine("Notes you wrote have been saved to the file...");
                        Console.WriteLine("To repeat the operation press 1 - to go to the main menu press 2");
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.Write("=> ");
                        Console.ResetColor();
                        string choice = Console.ReadLine();
                        if (choice == "1")
                        {
                            Console.Clear();
                            Note();
                        }
                        else if (choice == "2")
                        {
                            Console.Clear();
                            menu.showmenu();
                        }
                    }
                    else
                    {
                        Console.WriteLine("Error, file already exists. Please enter a different name.");
                        retry = true;
                    }
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error, please try again. Error message: " + ex.Message);
                retry = true;
            }
        }
        public void timer()
        {
            bool retry = true;
            try
            {
                while (retry)
                {
                    Console.WriteLine("Enter a value for the countdown...");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("=> ");
                    Console.ResetColor();
                    int time = Convert.ToInt32(Console.ReadLine());
                    while (time > 0)
                    {
                        Console.WriteLine("Counting down: " + time);
                        System.Threading.Thread.Sleep(1000);
                        Console.Beep(400,500);
                        time--;
                    }
                    Console.WriteLine("Countdown finished");
                    Console.Beep(400, 500);
                    Console.Beep(400, 500);
                    Console.WriteLine("Main menu 1 - Repeat operation 2");
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("=> ");
                    Console.ResetColor();
                    string choice = Console.ReadLine();
                    if (choice == "1")
                    {
                        retry = false;
                        Console.Clear();
                        menu.showmenu();
                    }
                    else if (choice == "2")
                    {
                        retry = true;
                        Console.Clear();
                        timer();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error, please try again. Error message: " + ex.Message);
            }
        }
    }
}

