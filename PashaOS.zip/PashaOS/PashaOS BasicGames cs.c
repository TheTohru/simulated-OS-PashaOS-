//PashaOS BasicGames.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PashaOS
{
    public class BasicGames
    {
        public void BasicGamesMenu()
        {
            Menu menu = new Menu();

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(@"                                                                               
,------.                ,--.                  ,----.                                    
|  .--. ' ,--,--. ,---. |  ,---.  ,--,--.    '  .-./    ,--,--.,--,--,--. ,---.  ,---.  
|  '--' |' ,-.  |(  .-' |  .-.  |' ,-.  |    |  | .---.' ,-.  ||        || .-. :(  .-'  
|  | --' \ '-'  |.-'  `)|  | |  |\ '-'  |    '  '--'  |\ '-'  ||  |  |  |\   --..-'  `) 
`--'      `--`--'`----' `--' `--' `--`--'     `------'  `--`--'`--`--`--' `----'`----'  
");
            Console.ResetColor();
            Console.WriteLine("Welcome to the basic games section, you can choose and play any game...");
            Console.WriteLine("[0] main menu");
            Console.WriteLine("[1] rock-paper-scissors");
            Console.WriteLine("[2] science and beyond");
            Console.WriteLine("[3] zombie war");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("=> ");
            Console.ResetColor();
            string choice = Console.ReadLine();

            switch(choice)
            {
                case "0":
                    Console.Clear();
                    menu.ShowMenu();
                    break;

                case "1":
                    Console.Clear();
                    Game1();
                    break;

                case "2":
                    // Not implemented yet
                    break;

                case "3":
                    Game2();
                    break;

                default:
                    Console.WriteLine("Please try again");
                    break;
            }
        }

        public void Game1()
        {
            bool again = true;
            while (again)
            {
                Console.WriteLine("Type 01 to exit");
                Console.WriteLine("Choose Rock (0), Paper (1), Scissors (2):");
                int user = Convert.ToInt32(Console.ReadLine());
                int pc = new Random().Next(0, 3);
                string[] choices = { "Rock", "Paper", "Scissors" };
                Console.WriteLine("Computer: " + choices[pc]);

                if (user == pc)
                {
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("It's a tie!");
                    Console.ResetColor();
                    Console.WriteLine("Computer: " + choices[pc]);
                    again = true;
                }    
                else if ((user == 0 && pc == 2) || (user == 1 && pc == 0) || (user == 2 && pc == 1))
                {
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("You won!");
                    Console.ResetColor();
                    Console.WriteLine("Computer: " + choices[pc]);
                    again = true;
                }
                else if(user == 1)
                {
                    Console.Clear();
                    again = false;
                    Menu menu = new Menu();
                    menu.ShowMenu();
                }
                else
                {
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("You lost!");
                    Console.ResetColor();
                    Console.WriteLine("Computer: " + choices[pc]);
                    again = true;
                }    
            }
        }

        public void Game2()
        {
            // user deals 12 damage
            // zombie deals 14 damage
            int zombieHealth = 100;
            int userHealth = 100;
            int userPoints = 0;

            Console.WriteLine("Welcome to zombie war, press any key to start...");
            Console.ReadKey();
            Console.Clear();
            Console.WriteLine("Game rules and info:");
            Console.WriteLine("You get points for killing zombies, as you get points you can buy items!");
            Console.WriteLine("You don't have to kill, but then you become the harmful side.");
            Console.WriteLine("Good luck!");
            Console.ReadKey();
            Console.Clear();

            bool again = true;

            while (again)
            {
                Console.WriteLine("A zombie is in front of you, press 's' to attack or 'p' to pass...");
                string choice = Console.ReadLine();

                if (choice == "s")
                {
                    Console.Clear();
                    userPoints += 23;
                    zombieHealth -= 12;
                    Console.WriteLine("You attacked the zombie with your bare hands, current zombie health: " + zombieHealth);
                    
                    if(zombieHealth <= 0)
                    {
                        again = false;
                        Console.Clear();
                        Console.WriteLine($"Zombie is dead! Your health: {userHealth}, Zombie health: {zombieHealth}");
                        Console.WriteLine("Points collected: " + userPoints);
                        Console.WriteLine("Press [1] to play again or [0] to exit...");
                        string choice1 = Console.ReadLine();
                        if (choice1 == "1")
                        {
                            Console.Clear();
                            again = true;
                        }
                        else if (choice1 == "0")
                        {
                            Console.Clear();
                            Menu menu = new Menu();
                            menu.ShowMenu();
                        }
                        else
                        {
                            Console.WriteLine("Error, please try again");
                        }
                    }
                    else if(userHealth <= 0)
                    {
                        again = false;
                        Console.Clear();
                        userPoints -= 6;
                        Console.WriteLine($"You died! Your health: {userHealth}, Zombie health: {zombieHealth}");
                        Console.WriteLine("Your points decreased, current points: " + userPoints);
                        Console.WriteLine("Press [1] to play again or [0] to exit...");
                        string choice2 = Console.ReadLine();
                        if (choice2 == "1")
                        {
                            Console.Clear();
                            again = true;
                        }
                        else if (choice2 == "0")
                        {
                            Console.Clear();
                            Menu menu = new Menu();
                            menu.ShowMenu();
                        }
                        else
                        {
                            Console.WriteLine("Error, please try again");
                        }
                    }
                }
                else if (choice == "p")
                {
                    Console.Clear();
                    userHealth -= 14;
                    Console.WriteLine("You did not attack the zombie and took damage. Your current health: " + userHealth);

                    if (zombieHealth <= 0)
                    {
                        again = false;
                        Console.Clear();
                        userPoints += 23;
                        Console.WriteLine($"You won! Zombie is dead! Your health: {userHealth}, Zombie health: {zombieHealth}");
                        Console.WriteLine("Points collected: " + userPoints);
                        Console.WriteLine("Press [1] to play again or [0] to exit...");
                        string choice3 = Console.ReadLine();
                        if (choice3 == "1")
                        {
                            Console.Clear();
                            again = true;
                        }
                        else if (choice3 == "0")
                        {
                            Console.Clear();
                            Menu menu = new Menu();
                            menu.ShowMenu();
                        }
                        else
                        {
                            Console.WriteLine("Error, please try again");
                        }
                    }
                    else if (userHealth <= 0)
                    {
                        again = false;
                        Console.Clear();
                        userPoints -= 6;
                        Console.WriteLine($"You died! Your health: {userHealth}, Zombie health: {zombieHealth}");
                        Console.WriteLine("Your points decreased, current points: " + userPoints);
                        Console.WriteLine("Press [1] to play again or [0] to exit...");
                        string choice4 = Console.ReadLine();
                        if (choice4 == "1")
                        {
                            Console.Clear();
                            again = true;
                        }
                        else if (choice4 == "0")
                        {
                            Console.Clear();
                            Menu menu = new Menu();
                            menu.ShowMenu();
                        }
                        else
                        {
                            Console.WriteLine("Error, please try again");
                        }
                    }
                }
                else
                {
                    userHealth -= 14;
                    Console.WriteLine("You did not attack the zombie and took damage. Your current health: " + userHealth);

                    if (zombieHealth <= 0)
                    {
                        again = false;
                        Console.Clear();
                        userPoints += 23;
                        Console.WriteLine($"Zombie is dead! Your health: {userHealth}, Zombie health: {zombieHealth}");
                        Console.WriteLine("Points collected: " + userPoints);
                        Console.WriteLine("Press [1] to play again or [0] to exit...");
                        string choice5 = Console.ReadLine();
                        if (choice5 == "1")
                        {
                            Console.Clear();
                            again = true;
                        }
                        else if (choice5 == "0")
                        {
                            Console.Clear();
                            Menu menu = new Menu();
                            menu.ShowMenu();
                        }
                        else
                        {
                            Console.WriteLine("Error, please try again");
                        }
                    }
                    else if (userHealth <= 0)
                    {
                        again = false;
                        Console.Clear();
                        userPoints -= 6;
                        Console.WriteLine($"You died! Your health: {userHealth}, Zombie health: {zombieHealth}");
                        Console.WriteLine("Your points decreased, current points: " + userPoints);
                        Console.WriteLine("Press [1] to play again or [0] to exit...");
                        string choice6 = Console.ReadLine();
                        if (choice6 == "1")
                        {
                            Console.Clear();
                            again = true;
                        }
                        else if (choice6 == "0")
                        {
                            Console.Clear();
                            Menu menu = new Menu();
                            menu.ShowMenu();
                        }
                        else
                        {
                            Console.WriteLine("Error, please try again");
                        }
                    }
                }
            }
        }
    }
}

