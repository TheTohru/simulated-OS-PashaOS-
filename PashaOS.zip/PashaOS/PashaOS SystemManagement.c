//PashaOS SystemManagement.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Management;

namespace PashaOS
{
    public class SystemManagement
    {
        public void ShowKnowledge()
        {
            Console.WriteLine("[WARNING] Information may differ or be incorrect depending on your operating system.");
            Console.WriteLine("CPU: " + GetKnowledge("Win32_Processor", "Name"));

            string ramStr = GetKnowledge("Win32_PhysicalMemory", "Capacity");
            if (ulong.TryParse(ramStr, out ulong ramBytes))
                Console.WriteLine("RAM: " + (ramBytes / 1024 / 1024 / 1024) + " GB");
            else
                Console.WriteLine("RAM: Information not available");

            Console.WriteLine("Disk: " + GetKnowledge("Win32_DiskDrive", "Model"));
            Console.WriteLine("GPU: " + GetKnowledge("Win32_VideoController", "Name"));

            Console.WriteLine(@"
            ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Required information has been displayed on the screen...");
            Console.ResetColor();
            Console.WriteLine("For menu press 0 - For settings press 1");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("=> ");
            Console.ResetColor();
            bool error = true;
            while (error)
            {
                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "0":
                        Console.Clear();
                        menu menu = new menu();
                        menu.ShowMenu();
                        break;

                    case "1":
                        Console.Clear();
                        settings settings = new settings();
                        settings.ShowSettings();
                        break;

                    default:
                        Console.WriteLine("Error, please try again");
                        error = true;
                        break;
                }
            }
        }

        static string GetKnowledge(string className, string property)
        {
            try
            {
                using (var searcher = new ManagementObjectSearcher($"select {property} from {className}"))
                {
                    foreach (var obj in searcher.Get())
                        return obj[property]?.ToString() ?? "Unknown";
                }
            }
            catch
            {
                return "Error, required information could not be retrieved.";
            }
            return "Information not found";
        }
    }
}

