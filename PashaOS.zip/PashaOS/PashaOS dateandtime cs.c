//PashaOS dateandtime.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PashaOS
{
    public class DateAndTime
    {
        public void ShowDateAndTime()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Current date and time: ");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Note: The date and time information is fetched only once, it will not be processed or shown again. It is displayed only a single time...");
            Console.WriteLine(DateTime.Now);
            Console.WriteLine(@"
            ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Menu 0 - Settings 1");
            Console.WriteLine(@"
            ");
            Console.Write("=> ");
            Console.ForegroundColor = ConsoleColor.Red;
            try
            {
                bool error = true;
                string choice = Console.ReadLine();

                while (error)
                {
                    switch (choice)
                    {
                        case "0":
                            Console.Clear();
                            menu menu = new menu();
                            menu.ShowMenu();
                            break;

                        case "1":
                            Console.Clear();
                            settings settings = new settings();
                            settings.ShowSettings();
                            break;

                        default:
                            Console.WriteLine("Invalid input, please try again...");
                            error = false;
                            break;
                    }
                }
            }
            catch (Exception error)
            {
                Console.WriteLine("Invalid input, please try again. Error message: " + error.Message);
            }
        }
    }
}

