//PashaOS Calculator.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PashaOS
{
    public class Calculator
    {
        public void ShowAddition()
        {
            bool error = true;
            while (error)
            {
                try
                {
                    Console.WriteLine("Addition selected, please enter the 1st and 2nd numbers");
                    Console.Write("1st number: ");
                    int n1 = Convert.ToInt32(Console.ReadLine());
                    Console.Write("2nd number: ");
                    int n2 = Convert.ToInt32(Console.ReadLine());
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("---------------------------------------------------------");
                    Console.ResetColor();
                    int result = n1 + n2;
                    Console.WriteLine("Sum: " + result);
                    Console.WriteLine("Entered numbers: " + n1 + " and " + n2);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("---------------------------------------------------------");

                    Console.WriteLine("To repeat the same operation press 1 - for main menu press 2");

                    Console.Write("=> ");
                    Console.ResetColor();
                    bool innerError = true;
                    while (innerError)
                    {
                        string choice = Console.ReadLine();
                        switch (choice)
                        {
                            case "1":
                                Console.Clear();
                                ShowAddition();
                                break;

                            case "2":
                                Console.Clear();
                                menu menu = new menu();
                                menu.ShowMenu();
                                break;

                            default:
                                Console.WriteLine("Invalid choice, please try again");
                                innerError = true;
                                break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Error, please try again. Error message: " + ex.Message);
                    Console.ResetColor();
                    error = true;
                }
            }
        }

        public void ShowSubtraction()
        {
            bool error = true;
            while (error)
            {
                try
                {
                    Console.WriteLine("Subtraction selected, please enter the 1st and 2nd numbers");
                    Console.Write("1st number: ");
                    int n1 = Convert.ToInt32(Console.ReadLine());
                    Console.Write("2nd number: ");
                    int n2 = Convert.ToInt32(Console.ReadLine());
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("---------------------------------------------------------");
                    Console.ResetColor();
                    int result = n1 - n2;
                    Console.WriteLine("Result: " + result);
                    Console.WriteLine("Entered numbers: " + n1 + " and " + n2);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("---------------------------------------------------------");

                    Console.WriteLine("To repeat the same operation press 1 - for main menu press 2");

                    Console.Write("=> ");
                    Console.ResetColor();
                    bool innerError = true;
                    while (innerError)
                    {
                        string choice = Console.ReadLine();
                        switch (choice)
                        {
                            case "1":
                                Console.Clear();
                                ShowSubtraction();
                                break;

                            case "2":
                                Console.Clear();
                                menu menu = new menu();
                                menu.ShowMenu();
                                break;

                            default:
                                Console.WriteLine("Invalid choice, please try again");
                                innerError = true;
                                break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Error, please try again. Error message: " + ex.Message);
                    Console.ResetColor();
                    error = true;
                }
            }
        }

        public void ShowDivision()
        {
            bool error = true;
            while (error)
            {
                try
                {
                    Console.WriteLine("Division selected, please enter the 1st and 2nd numbers");
                    Console.Write("1st number: ");
                    int n1 = Convert.ToInt32(Console.ReadLine());
                    Console.Write("2nd number: ");
                    int n2 = Convert.ToInt32(Console.ReadLine());
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("---------------------------------------------------------");
                    Console.ResetColor();
                    int result = n1 / n2;
                    Console.WriteLine("Result: " + result);
                    Console.WriteLine("Entered numbers: " + n1 + " and " + n2);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("---------------------------------------------------------");

                    Console.WriteLine("To repeat the same operation press 1 - for main menu press 2");

                    Console.Write("=> ");
                    Console.ResetColor();
                    bool innerError = true;
                    while (innerError)
                    {
                        string choice = Console.ReadLine();
                        switch (choice)
                        {
                            case "1":
                                Console.Clear();
                                ShowDivision();
                                break;

                            case "2":
                                Console.Clear();
                                menu menu = new menu();
                                menu.ShowMenu();
                                break;

                            default:
                                Console.WriteLine("Invalid choice, please try again");
                                innerError = true;
                                break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Error, please try again. Error message: " + ex.Message);
                    Console.ResetColor();
                    error = true;
                }
            }
        }

        public void ShowMultiplication()
        {
            bool error = true;
            while (error)
            {
                try
                {
                    Console.WriteLine("Multiplication selected, please enter the 1st and 2nd numbers");
                    Console.Write("1st number: ");
                    int n1 = Convert.ToInt32(Console.ReadLine());
                    Console.Write("2nd number: ");
                    int n2 = Convert.ToInt32(Console.ReadLine());
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("---------------------------------------------------------");
                    Console.ResetColor();
                    int result = n1 * n2;
                    Console.WriteLine("Result: " + result);
                    Console.WriteLine("Entered numbers: " + n1 + " and " + n2);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("---------------------------------------------------------");

                    Console.WriteLine("To repeat the same operation press 1 - for main menu press 2");

                    Console.Write("=> ");
                    Console.ResetColor();
                    bool innerError = true;
                    while (innerError)
                    {
                        string choice = Console.ReadLine();
                        switch (choice)
                        {
                            case "1":
                                Console.Clear();
                                ShowMultiplication();
                                break;

                            case "2":
                                Console.Clear();
                                menu menu = new menu();
                                menu.ShowMenu();
                                break;

                            default:
                                Console.WriteLine("Invalid choice, please try again");
                                innerError = true;
                                break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Error, please try again. Error message: " + ex.Message);
                    Console.ResetColor();
                    error = true;
                }
            }
        }

        public void ShowSquaringANumber()
        {
            bool error = true;
            while (error)
            {
                try
                {
                    Console.WriteLine("Squaring selected, please enter any number to square");
                    Console.Write("Enter any number: ");
                    int n1 = Convert.ToInt32(Console.ReadLine());
                    int result = n1 * n1;
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("------------------------------------------------------------------------------------");
                    Console.ResetColor();
                    Console.WriteLine("Result: " + result);
                    Console.WriteLine("Entered number: " + n1);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("------------------------------------------------------------------------------------");

                    Console.WriteLine("To repeat the same operation press 1 - for main menu press 2");

                    Console.Write("=> ");
                    Console.ResetColor();
                    bool innerError = true;
                    while (innerError)
                    {
                        string choice = Console.ReadLine();
                        switch (choice)
                        {
                            case "1":
                                Console.Clear();
                                ShowSquaringANumber();
                                break;

                            case "2":
                                Console.Clear();
                                menu menu = new menu();
                                menu.ShowMenu();
                                break;

                            default:
                                Console.WriteLine("Invalid choice, please try again");
                                innerError = true;
                                break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Error, please try again. Error message: " + ex.Message);
                    error = true;
                    Console.ResetColor();
                }
            }
        }

        public void ShowAverage()
        {
            bool error = true;
            while (error)
            {
                try
                {
                    Console.WriteLine("Average selected, please enter the 1st and 2nd numbers");
                    Console.Write("1st number: ");
                    int n1 = Convert.ToInt32(Console.ReadLine());
                    Console.Write("2nd number: ");
                    int n2 = Convert.ToInt32(Console.ReadLine());
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("---------------------------------------------------------");
                    Console.ResetColor();
                    int result = (n1 + n2) / 2;
                    Console.WriteLine("Result: " + result);
                    Console.WriteLine("Entered numbers: " + n1 + " and " + n2);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("---------------------------------------------------------");

                    Console.WriteLine("To repeat the same operation press 1 - for main menu press 2");

                    Console.Write("=> ");
                    Console.ResetColor();
                    bool innerError = true;
                    while (innerError)
                    {
                        string choice = Console.ReadLine();
                        switch (choice)
                        {
                            case "1":
                                Console.Clear();
                                ShowAverage();
                                break;

                            case "2":
                                Console.Clear();
                                menu menu = new menu();
                                menu.ShowMenu();
                                break;

                            default:
                                Console.WriteLine("Invalid choice, please try again");
                                innerError = true;
                                break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Error, please try again. Error message: " + ex.Message);
                    error = true;
                    Console.ResetColor();
                }
            }
        }
    }
}

