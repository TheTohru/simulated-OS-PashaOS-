//PashaOS boot.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PashaOS
{
    public class Boot
    {
        public void StartBoot()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("PashaOS operating system is starting...");
            Console.ResetColor();
            Console.WriteLine("Please wait...");
            System.Threading.Thread.Sleep(2500);
            Console.WriteLine("Boot process started...");
            System.Threading.Thread.Sleep(2500);
            Console.WriteLine("Boot process completed.");

            System.Threading.Thread.Sleep(2500);
            Console.WriteLine("Operating system data is being retrieved...");
            Console.WriteLine("Collecting data for the user...");
            System.Threading.Thread.Sleep(2500);
            Console.WriteLine("Starting...");
            System.Threading.Thread.Sleep(2500);
            Console.Clear();
            Console.WriteLine("Please wait a little longer...");
            System.Threading.Thread.Sleep(2500);
        }
    }
}

