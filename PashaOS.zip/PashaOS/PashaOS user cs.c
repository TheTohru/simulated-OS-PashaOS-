//PashaOS user.cs

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace PashaOS
{
    public class User
    {
        private static string Username { get; set; }
        private static string Password { get; set; }

        public static string Role;
        private static string CreationDate { get; set; }
        private protected string AdminCode = "PashaAdmin09";

        Menu menu = new Menu();
        Settings settings = new Settings();

        public void ShowUser()
        {
            // displays user information
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("Note: If the operating system (simulated app) is shut down, user data will be deleted. Data is kept in memory while the OS is running.");
            Console.ResetColor();
            Console.WriteLine("Your current user details:");
            Console.WriteLine("Username: " + UserInfo[0]);
            Console.WriteLine("Password: " + UserInfo[1]);
            Console.WriteLine("Current role: " + UserInfo[2]);
            Console.WriteLine("Account creation date: ");
            Console.WriteLine(CreationDate);

            Console.WriteLine(@"
            ");
            Console.WriteLine("0 for menu - 1 for settings");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("=> ");
            Console.ResetColor();
            try
            {
                bool hasError = true;
                while (hasError)
                {
                    string selection = Console.ReadLine();
                    switch (selection)
                    {
                        case "0":
                            Console.Clear();
                            menu.ShowMenu();
                            break;

                        case "1":
                            Console.Clear();
                            settings.ShowSettings();
                            break;

                        default:
                            Console.WriteLine("Error, please try again.");
                            hasError = true;
                            break;
                    }
                }
            }
            catch (Exception error)
            {
                Console.WriteLine("An error has occurred. Message: " + error.Message);
            }
        }

        public bool SetDefaultRole()
        {
            // assign default role
            if (string.IsNullOrEmpty(Role))
            {
                Role = "User";
                return true;
            }
            return false;
        }

        public static List<string> UserInfo = new List<string>(); // collection to store user info

        // receive and store user info
        public void Access()
        {
            SetDefaultRole();
            try
            {
                Console.WriteLine("Please enter and save your information.");
                Console.WriteLine("Your data will be temporarily stored in memory after registration.");
                Console.Write("Enter your username: ");
                Username = Console.ReadLine();
                Console.Write("Enter your password: ");
                Password = Console.ReadLine();
                Console.WriteLine(@"
                ");

                Console.WriteLine("Your info has been received. Username: " + Username + " Password: " + Password);
                Console.WriteLine("Do you confirm the entered information? Please check one last time! (y/n)");
                string confirm = Console.ReadLine();
                if (confirm == "y")
                {
                    if (!string.IsNullOrEmpty(Username) && !string.IsNullOrEmpty(Password))
                    {
                        UserInfo.Add(Username);
                        UserInfo.Add(Password);
                        UserInfo.Add(Role);
                        CreationDate = DateTime.Now.ToString();
                        menu.ShowMenu();
                    }
                    else
                    {
                        Console.WriteLine("Username or password cannot be empty.");
                    }
                }
                else if (confirm == "n")
                {
                    Console.Clear();
                    Console.WriteLine("You did not confirm the entered info. Would you like to try again? (y/n)");
                    string confirm2 = Console.ReadLine();
                    if (confirm2 == "y")
                    {
                        Console.Clear();
                        Access();
                    }
                    else if (confirm2 == "n")
                    {
                        Console.WriteLine("System is shutting down due to incomplete data...");
                    }
                    else
                    {
                        Console.WriteLine("Invalid input. System is shutting down...");
                    }
                }
            }
            catch (Exception error)
            {
                Console.WriteLine("An error occurred: " + error.Message);
                Console.WriteLine("System is shutting down...");
            }
        }

        // change username
        public void ChangeUsername()
        {
            if (UserInfo.Count > 0)
            {
                Console.WriteLine("Current username: " + UserInfo[0] + ". Enter the new one below:");
                string newUsername = Console.ReadLine();
                Username = newUsername;
                UserInfo[0] = Username;
                Console.WriteLine("Your username has been changed to " + Username + ". Redirecting to main menu...");
                System.Threading.Thread.Sleep(2500);
                Console.Clear();
                menu.ShowMenu();
            }
            else
            {
                Console.WriteLine("No user info found. Please create a user first.");
            }
        }

        // change password
        public void ChangePassword()
        {
            if (UserInfo.Count > 0)
            {
                Console.WriteLine("Current password: " + UserInfo[1] + ". Enter the new one below:");
                string newPassword = Console.ReadLine();
                Password = newPassword;
                UserInfo[1] = Password;
                Console.WriteLine("Your password has been changed to " + Password + ". Redirecting to main menu...");
                System.Threading.Thread.Sleep(2500);
                Console.Clear();
                menu.ShowMenu();
            }
            else
            {
                Console.WriteLine("No user info found. Please create a user first.");
            }
        }

        // change role
        public void ChangeRole()
        {
            Console.WriteLine("Current role: " + UserInfo[2] + ". Enter the new role below:");
            Console.WriteLine(@"
Role options:
[0] - Guest
[1] - User
[2] - Admin
            ");
            Console.BackgroundColor = ConsoleColor.Red;
            Console.Write("=> ");
            Console.ResetColor();

            string newRole = Console.ReadLine();

            if (newRole == "0")
            {
                Console.WriteLine("Are you sure you want to become a Guest? (y/n)");
                Console.WriteLine("[NOTE]: Becoming a guest will erase all your data.");
                string confirm = Console.ReadLine();
                if (confirm == "y")
                {
                    UserInfo[0] = "?";
                    UserInfo[1] = "?";
                    UserInfo[2] = "Guest";
                    Console.WriteLine("Your role has been changed to Guest. Redirecting to menu in a few seconds...");
                    System.Threading.Thread.Sleep(2500);
                    menu.ShowMenu();
                }
            }
            else if (newRole == "1")
            {
                if (UserInfo[2] == "User")
                {
                    Console.WriteLine("You are already a User. Would you like to try again? (y/n)");
                    string confirm4 = Console.ReadLine();
                    if (confirm4 == "y")
                    {
                        Console.Clear();
                        ChangeRole();
                    }
                    else if (confirm4 == "n")
                    {
                        Console.WriteLine("Redirecting to menu... ");
                        System.Threading.Thread.Sleep(2500);
                        menu.ShowMenu();
                    }
                }
                else
                {
                    UserInfo[2] = "User";
                    Console.WriteLine("Your role has been changed to User. Redirecting to menu in a few seconds...");
                    System.Threading.Thread.Sleep(2500);
                    menu.ShowMenu();
                }
            }
            else if (newRole == "2")
            {
                Console.WriteLine("Enter the security code to change your role to 'Admin':");
                string security = Console.ReadLine();
                if (security == AdminCode)
                {
                    UserInfo[2] = "Admin";
                    Console.WriteLine("Your role has been changed to Admin. Redirecting to menu in a few seconds...");
                    System.Threading.Thread.Sleep(2500);
                    menu.ShowMenu();
                }
                else
                {
                    Console.WriteLine("Incorrect code. If you don't know it, you do not have the permission. Redirecting to menu...");
                    System.Threading.Thread.Sleep(2500);
                    menu.ShowMenu();
                }
            }
        }
    }
}

